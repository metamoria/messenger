import { NgModule } from '@angular/core';
import { CDVPipes } from './safe';

@NgModule({
declarations: [CDVPipes],
imports: [],
exports: [CDVPipes]
})
export class CdvPipesModule {}