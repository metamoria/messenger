import { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.hollamessenger.app',
  appName: 'Holla Messenger',
  webDir: 'www',
  bundledWebRuntime: false,
   plugins: {
    Keyboard: {
      resize: "none"
    },
  },
};

export default config;
